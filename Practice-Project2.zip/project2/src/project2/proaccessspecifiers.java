package project2;
 // using protected access specifiers

public class proaccessspecifiers {

	protected void display() 
  { 
      System.out.println("This is protected access specifier"); 
  } 
}


