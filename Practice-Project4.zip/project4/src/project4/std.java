package project4;

public class std {
	int id;
	String name;

	std(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}


public static void main(String[] args) {

	std std1=new std(2,"Alex");
	std std2=new std(10,"Annie");
	std1.display();
	std2.display();
		}
}
